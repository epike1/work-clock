import javax.swing.*;

public class NameAndPay {
    private JButton mcNextButton;
    private JTextField textField1;
}

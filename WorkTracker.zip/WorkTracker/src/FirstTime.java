import javax.swing.*;

public class FirstTime {
    private JButton mcBeginButton;
}
